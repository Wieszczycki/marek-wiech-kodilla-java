create
    definer = kodilla_user@localhost function VipLevel(booksrented int) returns varchar(20) deterministic
BEGIN
DECLARE result VARCHAR(20) DEFAULT 'Standard customer';
IF booksrented >= 10 THEN
    SET result = 'Gold customer';
ELSEIF booksrented >= 5 AND booksrented < 10 THEN
    SET result = 'Silver customer';
ELSEIF booksrented >= 2 AND booksrented < 5 THEN
    SET result = 'Bronze customer';
ELSE
    SET result = 'Standard customer';
END IF;
RETURN result;
END;

