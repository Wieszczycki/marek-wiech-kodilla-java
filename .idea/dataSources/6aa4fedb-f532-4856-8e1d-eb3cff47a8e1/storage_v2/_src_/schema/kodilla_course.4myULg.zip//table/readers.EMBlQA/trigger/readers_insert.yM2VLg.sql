create definer = kodilla_user@localhost trigger READERS_INSERT
    after insert
    on readers
    for each row
BEGIN
        INSERT INTO READERS_AUD (EVENT_DATE, EVENT_TYPE, READER_ID, NEW_FIRSTNAME, NEW_LASTNAME, NEW_PESELID)
        VALUE(CURTIME(), "INSERT", NEW.READER_ID, NEW.FIRSTNAME, NEW.LASTNAME, NEW.PESELID);
    END;

