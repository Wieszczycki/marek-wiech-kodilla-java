create definer = kodilla_user@localhost trigger RENTS_DELETE
    after delete
    on rents
    for each row
BEGIN
    INSERT INTO RENTS_AUD (EVENT_DATE, EVENT_TYPE, RENT_ID) -- [2]
        VALUE(CURTIME(), "DELETE", OLD.RENT_ID);             -- [3]
END;

