create
    definer = kodilla_user@localhost procedure CalcPhoneStats()
BEGIN
    DECLARE K INT(11) DEFAULT 100000;
    DECLARE QTY INT(11);
    WHILE (K < 100000000) DO
            SELECT COUNT(*)
                FROM PHONES
                WHERE PHONENUM BETWEEN (K-99999) AND K
                INTO QTY;
            INSERT INTO PHONESTATS (RANGE_FROM, RANGE_TO, QUANTITY)
                VALUES ((K-99999), K, QTY);
            COMMIT;
            SET K = K + 100000;
        END WHILE;
END;

