create
    definer = kodilla_user@localhost procedure ListBooks()
BEGIN
    SELECT BOOK_ID, TITLE, PUBYEAR FROM BOOKS;
END;

