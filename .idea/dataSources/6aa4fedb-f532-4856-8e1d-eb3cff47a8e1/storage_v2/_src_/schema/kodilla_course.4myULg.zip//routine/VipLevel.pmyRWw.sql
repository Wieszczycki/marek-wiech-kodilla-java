create
    definer = kodilla_user@localhost function VipLevel() returns varchar(20) deterministic
BEGIN
    DECLARE result VARCHAR(20) DEFAULT 'Standard customer';	-- [1]
    RETURN result;						                    -- [2]
END;

