create
    definer = kodilla_user@localhost procedure FillTestData()
BEGIN
    DECLARE K INT DEFAULT 0;
    WHILE (K < 100000) DO
            INSERT INTO PHONES (PHONENUM,
                                FIRSTNAME,
                                LASTNAME)
            VALUES(ROUND(RAND()*1000000000),
                   CONCAT('Firstname number ', K),
                   CONCAT('Lastname number ', K));
            IF (MOD(K, 5000) = 0) THEN
                COMMIT;
            END IF;
            SET K = K + 1;
        END WHILE;
    COMMIT;
END;

