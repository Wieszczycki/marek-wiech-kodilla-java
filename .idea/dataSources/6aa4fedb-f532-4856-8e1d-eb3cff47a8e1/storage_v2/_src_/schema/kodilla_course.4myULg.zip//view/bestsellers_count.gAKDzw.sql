create definer = root@localhost view bestsellers_count as
select sum(`books`.`BESTSELLER`) AS `ALL_BESTSELLERS`
from `books`;

