create
    definer = kodilla_user@localhost procedure UpdateBestsellers()
BEGIN
    DECLARE BK_ID, RENTED INT;
    DECLARE BEST BOOLEAN;
    DECLARE FINISHED INT DEFAULT 0;
    DECLARE ALL_BOOKS CURSOR FOR SELECT BOOK_ID FROM books;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET FINISHED = 1;
    OPEN ALL_BOOKS;
    WHILE (FINISHED = 0) DO
        FETCH ALL_BOOKS INTO BK_ID;
        IF (FINISHED = 0) THEN
            SELECT COUNT(*) FROM RENTS
            WHERE BOOK_ID = BK_ID
            INTO RENTED;

            SET BEST = false;
            IF (RENTED > 2) THEN
                SET BEST = true;
            END IF;

            UPDATE books SET BESTSELLER = BEST
                WHERE BOOK_ID = BK_ID;
            COMMIT;
        END IF;
    END WHILE;
    CLOSE ALL_BOOKS;
END;

