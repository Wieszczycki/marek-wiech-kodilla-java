create
    definer = kodilla_user@localhost function ListUsers(user_id int) returns varchar(255) deterministic
BEGIN
    DECLARE result VARCHAR(255);
    DECLARE t1, t2 VARCHAR(20);
    IF user_id <= 0 THEN
        SET result = 'Reader ID is 0 or less!';
    ELSE
        SELECT FIRSTNAME INTO t1 FROM readers WHERE READER_ID=user_id;
        SELECT LASTNAME INTO t2 FROM readers WHERE READER_ID=user_id;
        SET result = CONCAT(user_id, ' = ', t1, ' ', t2);
    END IF;
    RETURN result;
END;

